# Native RDML/XML importer --------------------------------------------------

.rdmlImportRdml <- function(
    fileName,
    showProgress = TRUE,
    conditionsSep = NULL,
    cluster = NULL,
    format = "rdml") {
  
  rdmlObj <- list(
    dateMade = NA_character_,
    dateUpdated = NA_character_,
    id = list(),
    experimenter = list(),
    documentation = list(),
    dye = list(),
    sample = list(),
    target = list(),
    thermalCyclingConditions = list(),
    experiment = list()
  )
  
  asTableRdml <- function(rdmlObj) {
    rows <- list()
    n <- 0L
    
    for (exp in rdmlObj$experiment) {
      runs <- S7::prop(exp, "run")
      if (.isSingleNA(runs) || !length(runs)) next
      
      for (run in runs) {
        reacts <- S7::prop(run, "react")
        if (.isSingleNA(reacts) || !length(reacts)) next
        
        for (react in reacts) {
          n <- n + 1L
          rows[[n]] <- data.frame(
            reactId = suppressWarnings(base::as.integer(react@id@id)),
            sample = react@sample@id,
            stringsAsFactors = FALSE
          )
        }
      }
    }
    
    if (!length(rows)) {
      return(data.table::data.table(
        reactId = integer(),
        sample = character()
      ))
    }
    
    data.table::as.data.table(do.call(rbind, rows))
  }
  
  # Parse optional object only when the XML node exists.
  optionalNode <- function(tree, path, FUN, ns = rdmlEnv$ns) {
    node <- xml2::xml_find_first(tree, path, ns)
    if (.isXmlMissing(node)) return(NA)
    FUN(node)
  }
  

  parseNumericValues <- function(tree, path) {
    nodes <- xml2::xml_find_all(
      tree,
      path,
      rdmlEnv$ns
    )

    if (!length(nodes)) {
      return(NA_real_)
    }

    values <- suppressWarnings(
      as.numeric(
        xml2::xml_text(nodes)
      )
    )

    values <- values[!is.na(values)]

    if (!length(values)) {
      NA_real_
    } else {
      values
    }
  }

  parseIdRefs <- function(tree, path) {
    .xmlNodesApply(
      xml2::xml_find_all(tree, path, rdmlEnv$ns),
      .genIdRef
    )
  }
  
  parseXrefs <- function(tree, path = "rdml:xRef") {
    .xmlNodesApply(
      xml2::xml_find_all(tree, path, rdmlEnv$ns),
      function(node) {
        xRefType(
          name = .getTextValue(node, "rdml:name"),
          id = .getTextValue(node, "rdml:id")
        )
      }
    )
  }
  
  parseAnnotations <- function(sample) {
    .xmlNodesApply(
      xml2::xml_find_all(sample, "rdml:annotation", rdmlEnv$ns),
      function(node) {
        annotationType(
          property = .getTextValue(node, "rdml:property"),
          value = .getTextValue(node, "rdml:value")
        )
      }
    )
  }
  
  parseSampleTypes <- function(sample) {
    nodes <- xml2::xml_find_all(
      sample,
      "rdml:type",
      rdmlEnv$ns
    )

    .compact(.xmlNodesApply(
      nodes,
      function(node) {
        targetId <- xml2::xml_attr(
          node,
          "targetId"
        )

        if (is.na(targetId)) {
          targetId <- xml2::xml_attr(
            node,
            "target"
          )
        }

        # RDML permits both:
        #
        #   <type>std</type>
        #
        # and:
        #
        #   <type targetId="ACTB">std</type>
        #
        # A missing targetId is therefore preserved as a global sample
        # role rather than discarded or duplicated for every target.
        targetRef <- if (
          is.na(targetId) ||
          !nzchar(targetId)
        ) {
          NA
        } else {
          idReferenceType(targetId)
        }

        sampleTargetType(
          targetId = targetRef,
          sampleType = sampleTypeType(
            xml2::xml_text(node)
          )
        )
      }
    ))
  }
  parseQuantities <- function(sample) {
    nodes <- xml2::xml_find_all(sample, "rdml:quantity", rdmlEnv$ns)
    .compact(.xmlNodesApply(nodes, function(node) {
      targetId <- xml2::xml_attr(node, "targetId")
      if (is.na(targetId)) targetId <- xml2::xml_attr(node, "target")
      if (is.na(targetId) || !nzchar(targetId)) return(NULL)
      
      quantityType(
        targetId = idReferenceType(targetId),
        value = .getNumericValue(node, "rdml:value"),
        unit = quantityUnitType(.getTextValue(node, "rdml:unit"))
      )
    }))
  }
  
  parseOligo <- function(target, path) {
    node <- xml2::xml_find_first(target, path, rdmlEnv$ns)
    if (.isXmlMissing(node)) return(NA)
    
    seq <- .getTextValue(node, "rdml:sequence")
    if (is.na(seq)) return(NA)
    
    oligoType(
      threePrimeTag = .getTextValue(node, "rdml:threePrimeTag"),
      fivePrimeTag = .getTextValue(node, "rdml:fivePrimeTag"),
      sequence = seq
    )
  }
  
  parseSequences <- function(target) {
    node <- xml2::xml_find_first(target, "rdml:sequences", rdmlEnv$ns)
    if (.isXmlMissing(node)) return(NA)
    
    sequencesType(
      forwardPrimer = parseOligo(target, "rdml:sequences/rdml:forwardPrimer"),
      reversePrimer = parseOligo(target, "rdml:sequences/rdml:reversePrimer"),
      probe1 = parseOligo(target, "rdml:sequences/rdml:probe1"),
      probe2 = parseOligo(target, "rdml:sequences/rdml:probe2"),
      amplicon = parseOligo(target, "rdml:sequences/rdml:amplicon")
    )
  }
  
  parseMeasure <- function(tree, path) {
    txt <- .getTextValue(tree, path)
    if (is.na(txt)) return(NA)
    measureType(txt)
  }
  
  parseTemperature <- function(step) {
    node <- xml2::xml_find_first(step, "rdml:temperature", rdmlEnv$ns)
    if (.isXmlMissing(node)) return(NA)
    
    temperatureType(
      temperature = .getNumericValue(node, "rdml:temperature"),
      duration = .getIntegerValue(node, "rdml:duration"),
      temperatureChange = .getNumericValue(node, "rdml:temperatureChange"),
      durationChange = .getIntegerValue(node, "rdml:durationChange"),
      measure = parseMeasure(node, "rdml:measure"),
      ramp = .getNumericValue(node, "rdml:ramp")
    )
  }
  
  parseGradient <- function(step) {
    node <- xml2::xml_find_first(step, "rdml:gradient", rdmlEnv$ns)
    if (.isXmlMissing(node)) return(NA)
    
    gradientType(
      highTemperature = .getNumericValue(node, "rdml:highTemperature"),
      lowTemperature = .getNumericValue(node, "rdml:lowTemperature"),
      duration = .getIntegerValue(node, "rdml:duration"),
      temperatureChange = .getNumericValue(node, "rdml:temperatureChange"),
      durationChange = .getIntegerValue(node, "rdml:durationChange"),
      measure = parseMeasure(node, "rdml:measure"),
      ramp = .getNumericValue(node, "rdml:ramp")
    )
  }
  
  parseLoop <- function(step) {
    node <- xml2::xml_find_first(step, "rdml:loop", rdmlEnv$ns)
    if (.isXmlMissing(node)) return(NA)
    
    do.call(
      loopType,
      list(
        goto = .getIntegerValue(node, "rdml:goto"),
        "repeat" = .getIntegerValue(node, "rdml:repeat")
      )
    )
  }
  
  parsePause <- function(step) {
    node <- xml2::xml_find_first(step, "rdml:pause", rdmlEnv$ns)
    if (.isXmlMissing(node)) return(NA)
    pauseType(temperature = .getNumericValue(node, "rdml:temperature"))
  }
  
  parseLidOpen <- function(step) {
    node <- xml2::xml_find_first(step, "rdml:lidOpen", rdmlEnv$ns)
    if (.isXmlMissing(node)) return(NA)
    lidOpenType()
  }
  
  parseAdp <- function(data) {
    nodes <- xml2::xml_find_all(data, "rdml:adp", rdmlEnv$ns)
    if (!length(nodes)) return(NA)
    
    cyc <- vapply(seq_along(nodes), function(i) {
      .getNumericValue(nodes[[i]], "rdml:cyc")
    }, numeric(1))
    fluor <- vapply(seq_along(nodes), function(i) {
      .getNumericValue(nodes[[i]], "rdml:fluor")
    }, numeric(1))
    tmp <- vapply(seq_along(nodes), function(i) {
      .getNumericValue(nodes[[i]], "rdml:tmp")
    }, numeric(1))
    
    if (all(is.na(tmp))) {
      dpAmpCurveType(
        data.table::data.table(cyc = cyc, fluor = fluor)
      )
    } else {
      dpAmpCurveType(
        data.table::data.table(cyc = cyc, tmp = tmp, fluor = fluor)
      )
    }
  }
  
  parseMdp <- function(data) {
    nodes <- xml2::xml_find_all(data, "rdml:mdp", rdmlEnv$ns)
    if (!length(nodes)) return(NA)
    
    tmp <- vapply(seq_along(nodes), function(i) {
      .getNumericValue(nodes[[i]], "rdml:tmp")
    }, numeric(1))
    fluor <- vapply(seq_along(nodes), function(i) {
      .getNumericValue(nodes[[i]], "rdml:fluor")
    }, numeric(1))
    
    dpMeltingCurveType(
      data.table::data.table(tmp = tmp, fluor = fluor)
    )
  }
  
  fromRDML <- function() {
    rdmlEnv$ns <- NULL
    
    dilutionsR <- NULL
    conditionsR <- NULL
    refGenesR <- NULL
    isRocheArchive <- FALSE
    
    if (identical(format, "xml")) {
      rdmlDoc <- xml2::read_xml(fileName)
      rdmlEnv$ns <- xml2::xml_ns(rdmlDoc)
      if (!("rdml" %in% names(rdmlEnv$ns))) {
        rdmlEnv$ns <- xml2::xml_ns_rename(rdmlEnv$ns, d1 = "rdml")
      }
    } else {
      uniqFolder <- tempfile("rdml-")
      dir.create(uniqFolder, recursive = TRUE)
      on.exit(unlink(uniqFolder, recursive = TRUE), add = TRUE)
      
      unzippedRdml <- utils::unzip(fileName, exdir = uniqFolder)
      if (!length(unzippedRdml)) stop("RDML archive is empty")
      
      isRocheArchive <- length(unzippedRdml) > 1L &&
        file.exists(file.path(uniqFolder, "rdml_data.xml"))
      
      if (isRocheArchive) {
        rdmlDoc <- xml2::read_xml(file.path(uniqFolder, "rdml_data.xml"))
        dilutionsR <- .getDilutionsRoche(uniqFolder)
        conditionsR <- .getConditionsRoche(uniqFolder)
        refGenesR <- .getRefGenesRoche(uniqFolder)
        rdmlEnv$ns <- xml2::xml_ns_rename(xml2::xml_ns(rdmlDoc), d1 = "rdml")
      } else {
        rdmlDoc <- xml2::read_xml(unzippedRdml[[1]])
        rdmlEnv$ns <- xml2::xml_ns(rdmlDoc)
        if (!("rdml" %in% names(rdmlEnv$ns))) {
          rdmlEnv$ns <- xml2::xml_ns_rename(rdmlEnv$ns, d1 = "rdml")
        }
      }
    }
    
    rdmlObj$dateMade <- .getTextValue(rdmlDoc, "/rdml:rdml/rdml:dateMade")
    rdmlObj$dateUpdated <- .getTextValue(rdmlDoc, "/rdml:rdml/rdml:dateUpdated")
    
    # id -------------------------------------------------------------------
    rdmlObj$id <- .xmlNodesApply(
      xml2::xml_find_all(rdmlDoc, "/rdml:rdml/rdml:id", rdmlEnv$ns),
      function(node) {
        rdmlIdType(
          publisher = .getTextValue(node, "rdml:publisher"),
          serialNumber = .getTextValue(node, "rdml:serialNumber"),
          MD5Hash = .getTextValue(node, "rdml:MD5Hash")
        )
      }
    )
    
    publisher <- if (length(rdmlObj$id)) {
      S7::prop(rdmlObj$id[[1]], "publisher")
    } else {
      NA_character_
    }
    isRoche <- identical(publisher, "Roche Diagnostics")
    
    requiredExperimenterText <- function(node, path) {
      value <- .getTextValue(
        node,
        path
      )
      
      if (
        is.na(value) ||
        !nzchar(trimws(value))
      ) {
        return("Unknown")
      }
      
      value
    }
    
    # experimenter ---------------------------------------------------------
    rdmlObj$experimenter <- .xmlNodesApply(
      xml2::xml_find_all(
        rdmlDoc,
        "/rdml:rdml/rdml:experimenter",
        rdmlEnv$ns
      ),
      function(node) {
        experimenterType(
          id = .genId(node),
          firstName = requiredExperimenterText(
            node,
            "rdml:firstName"
          ),
          lastName = requiredExperimenterText(
            node,
            "rdml:lastName"
          ),
          email = .getTextValue(
            node,
            "rdml:email"
          ),
          labName = .getTextValue(
            node,
            "rdml:labName"
          ),
          labAddress = .getTextValue(
            node,
            "rdml:labAddress"
          )
        )
      }
    )
    
    # documentation --------------------------------------------------------
    rdmlObj$documentation <- .xmlNodesApply(
      xml2::xml_find_all(rdmlDoc, "/rdml:rdml/rdml:documentation", rdmlEnv$ns),
      function(node) {
        documentationType(
          id = .genId(node),
          text = .getTextValue(node, "rdml:text")
        )
      }
    )
    
    # dye ------------------------------------------------------------------
    rdmlObj$dye <- .xmlNodesApply(
      xml2::xml_find_all(rdmlDoc, "/rdml:rdml/rdml:dye", rdmlEnv$ns),
      function(node) {
        chemistry <- .getTextValue(node, "rdml:dyeChemistry")
        dyeType(
          id = .genId(node),
          description = .getTextValue(node, "rdml:description"),
          dyeChemistry = if (is.na(chemistry)) NA else dyeChemistryType(chemistry)
        )
      }
    )
    
    # sample ---------------------------------------------------------------
    rdmlObj$sample <- .compact(.xmlNodesApply(
      xml2::xml_find_all(rdmlDoc, "/rdml:rdml/rdml:sample", rdmlEnv$ns),
      function(sample) {
        id <- xml2::xml_attr(sample, "id")
        rawType <- .getTextValue(sample, "rdml:type")
        
        # Roche uses ntp as an omitted/empty sample marker.
        if (identical(rawType, "ntp")) return(NULL)
        
        cdnaNode <- xml2::xml_find_first(sample, "rdml:cdnaSynthesisMethod", rdmlEnv$ns)
        cdna <- if (.isXmlMissing(cdnaNode)) {
          NA
        } else {
          thermalNode <- xml2::xml_find_first(
            cdnaNode,
            "rdml:thermalCyclingConditions",
            rdmlEnv$ns
          )
          primingMethod <- .getTextValue(
            cdnaNode,
            "rdml:primingMethod"
          )
          
          cdnaSynthesisMethodType(
            enzyme = .getTextValue(cdnaNode, "rdml:enzyme"),
            primingMethod = if (is.na(primingMethod)) {
              NA
            } else {
              primingMethodType(primingMethod)
            },
            dnaseTreatment = .getLogicalValue(cdnaNode, "rdml:dnaseTreatment"),
            thermalCyclingConditions = if (.isXmlMissing(thermalNode)) {
              NA
            } else {
              .genIdRef(thermalNode)
            }
          )
        }
        
        templateNode <- xml2::xml_find_first(sample, "rdml:templateQuantity", rdmlEnv$ns)
        templateQuantity <- if (.isXmlMissing(templateNode)) {
          NA
        } else {
          templateQuantityType(
            conc = .getNumericValue(templateNode, "rdml:conc"),
            nucleotide = nucleotideType(.getTextValue(templateNode, "rdml:nucleotide"))
          )
        }
        
        sampleType(
          id = idType(id),
          description = .getTextValue(sample, "rdml:description"),
          documentation = parseIdRefs(sample, "rdml:documentation"),
          xRef = parseXrefs(sample),
          annotation = parseAnnotations(sample),
          type = parseSampleTypes(sample),
          interRunCalibrator = .getLogicalValue(sample, "rdml:interRunCalibrator"),
          quantity = parseQuantities(sample),
          calibratorSample = .getLogicalValue(sample, "rdml:calibratorSample"),
          cdnaSynthesisMethod = cdna,
          templateQuantity = templateQuantity
        )
      }
    ))
    
    # target ---------------------------------------------------------------
    rdmlObj$target <- .xmlNodesApply(
      xml2::xml_find_all(rdmlDoc, "/rdml:rdml/rdml:target", rdmlEnv$ns),
      function(target) {
        targetId <- xml2::xml_attr(target, "id")
        if (isRoche && grepl("@", targetId, fixed = TRUE)) {
          targetId <- sub("^.*@", "", targetId)
        }
        
        dyeNode <- xml2::xml_find_first(target, "rdml:dyeId", rdmlEnv$ns)
        dyeId <- if (.isXmlMissing(dyeNode)) {
          stop("target '", targetId, "' has no dyeId")
        } else {
          idAttr <- xml2::xml_attr(dyeNode, "id")
          if (!is.na(idAttr)) idReferenceType(idAttr) else idReferenceType(xml2::xml_text(dyeNode))
        }
        
        commercialNode <- xml2::xml_find_first(target, "rdml:commercialAssay", rdmlEnv$ns)
        commercial <- if (.isXmlMissing(commercialNode)) {
          NA
        } else {
          commercialAssayType(
            company = .getTextValue(commercialNode, "rdml:company"),
            orderNumber = .getTextValue(commercialNode, "rdml:orderNumber")
          )
        }
        
        targetType(
          id = idType(targetId),
          description = .getTextValue(target, "rdml:description"),
          documentation = parseIdRefs(target, "rdml:documentation"),
          xRef = parseXrefs(target),
          type = targetTypeType(.getTextValue(target, "rdml:type")),
          amplificationEfficiencyMethod = .getTextValue(target, "rdml:amplificationEfficiencyMethod"),
          amplificationEfficiency = .getNumericValue(target, "rdml:amplificationEfficiency"),
          amplificationEfficiencySE = .getNumericValue(target, "rdml:amplificationEfficiencySE"),
          meltingTemperature = .getNumericValue(target, "rdml:meltingTemperature"),
          detectionLimit = .getNumericValue(target, "rdml:detectionLimit"),
          dyeId = dyeId,
          sequences = parseSequences(target),
          commercialAssay = commercial
        )
      }
    )
    
    # thermalCyclingConditions ---------------------------------------------
    rdmlObj$thermalCyclingConditions <- .xmlNodesApply(
      xml2::xml_find_all(
        rdmlDoc,
        "/rdml:rdml/rdml:thermalCyclingConditions",
        rdmlEnv$ns
      ),
      function(tcc) {
        steps <- .xmlNodesApply(
          xml2::xml_find_all(tcc, "rdml:step", rdmlEnv$ns),
          function(step) {
            stepType(
              nr = .getIntegerValue(step, "rdml:nr"),
              description = .getTextValue(step, "rdml:description"),
              temperature = parseTemperature(step),
              gradient = parseGradient(step),
              loop = parseLoop(step),
              pause = parsePause(step),
              lidOpen = parseLidOpen(step)
            )
          }
        )
        
        thermalCyclingConditionsType(
          id = .genId(tcc),
          description = .getTextValue(tcc, "rdml:description"),
          documentation = parseIdRefs(tcc, "rdml:documentation"),
          lidTemperature = .getNumericValue(tcc, "rdml:lidTemperature"),
          experimenter = parseIdRefs(tcc, "rdml:experimenter"),
          step = steps
        )
      }
    )
    
    # data -----------------------------------------------------------------
    GetData <- function(data) {
      tarNode <- xml2::xml_find_first(data, "rdml:tar", rdmlEnv$ns)
      tarId <- if (.isXmlMissing(tarNode)) NA_character_ else xml2::xml_attr(tarNode, "id")
      
      if (isRoche && !is.na(tarId) && grepl("@", tarId, fixed = TRUE)) {
        tarId <- sub("^.*@", "", tarId)
      }
      
      if (is.na(tarId) || !nzchar(tarId)) {
        stop("RDML data element has no target id")
      }
      
      dataType(
        targetId = idReferenceType(tarId),
        cq = .getNumericValue(data, "rdml:cq"),
        N0 = .getNumericValue(data, "rdml:N0"),
        ampEffMet = .getTextValue(data, "rdml:ampEffMet"),
        ampEff = .getNumericValue(data, "rdml:ampEff"),
        ampEffSE = .getNumericValue(data, "rdml:ampEffSE"),
        corrF = .getNumericValue(data, "rdml:corrF"),
        corrP = .getNumericValue(data, "rdml:corrP"),
        meltTemp = parseNumericValues(data, "rdml:meltTemp"),
        excl = .getTextValue(data, "rdml:excl"),
        note = .getTextValue(data, "rdml:note"),
        adp = parseAdp(data),
        mdp = parseMdp(data),
        endPt = .getNumericValue(data, "rdml:endPt"),
        bgFluor = .getNumericValue(data, "rdml:bgFluor"),
        bgFluorSlp = .getNumericValue(data, "rdml:bgFluorSlp"),
        quantFluor = .getNumericValue(data, "rdml:quantFluor")
      )
    }
    
    GetPartitionData <- function(data) {
      tarNode <- xml2::xml_find_first(data, "rdml:tar", rdmlEnv$ns)
      tarId <- if (.isXmlMissing(tarNode)) NA_character_ else xml2::xml_attr(tarNode, "id")
      if (is.na(tarId) || !nzchar(tarId)) stop("partition data has no target id")
      
      partitionDataType(
        targetId = idReferenceType(tarId),
        excluded = .getTextValue(data, "rdml:excluded"),
        note = .getTextValue(data, "rdml:note"),
        pos = .getIntegerValue(data, "rdml:pos"),
        neg = .getIntegerValue(data, "rdml:neg"),
        undef = .getIntegerValue(data, "rdml:undef"),
        excl = .getIntegerValue(data, "rdml:excl"),
        conc = .getNumericValue(data, "rdml:conc")
      )
    }
    
    GetPartitions <- function(react) {
      node <- xml2::xml_find_first(react, "rdml:partitions", rdmlEnv$ns)
      if (.isXmlMissing(node)) return(NA)
      
      partitionsType(
        volume = .getNumericValue(node, "rdml:volume"),
        endPtTable = .getTextValue(node, "rdml:endPtTable"),
        data = .xmlNodesApply(
          xml2::xml_find_all(node, "rdml:data", rdmlEnv$ns),
          GetPartitionData
        )
      )
    }
    
    # react ----------------------------------------------------------------
    GetReact <- function(
    react,
    pcrFormat = pcrFormatType(
      rows = 8L,
      columns = 12L,
      rowLabel = labelFormatType("ABC"),
      columnLabel = labelFormatType("123")
    )) {
      reactId <- xml2::xml_attr(react, "id")
      reactIdCorrected <- suppressWarnings(base::as.integer(reactId))
      if (is.na(reactIdCorrected)) {
        reactIdCorrected <- .fromPositionToId(reactId, pcrFormat)
      }
      
      sampleNode <- xml2::xml_find_first(react, "rdml:sample", rdmlEnv$ns)
      if (.isXmlMissing(sampleNode)) stop("react '", reactId, "' has no sample")
      sampleId <- xml2::xml_attr(sampleNode, "id")
      
      if (isRoche) {
        sampleObj <- .listGetByKey(rdmlObj$sample, sampleId, "id")
        if (is.null(sampleObj)) return(NULL)
        sampleId <- S7::prop(sampleObj, "description")
      }
      
      reactType(
        id = idType(as.character(reactIdCorrected)),
        sample = idReferenceType(sampleId),
        data = .xmlNodesApply(
          xml2::xml_find_all(react, "rdml:data", rdmlEnv$ns),
          GetData
        ),
        partitions = {
          partitions <- GetPartitions(react)
          if (.isSingleNA(partitions)) list() else list(partitions)
        }
      )
    }
    
    # run ------------------------------------------------------------------
    GetRun <- function(run) {
      runId <- xml2::xml_attr(run, "id")
      
      pcrFormat <- {
        pcrFormatStr <- .getTextValue(run, "rdml:pcrFormat")
        if (!is.na(pcrFormatStr) && grepl("well", pcrFormatStr, ignore.case = TRUE)) {
          if (grepl("96-well", pcrFormatStr, ignore.case = TRUE)) {
            pcrFormatType(
              rows = 8L,
              columns = 12L,
              rowLabel = labelFormatType("ABC"),
              columnLabel = labelFormatType("123")
            )
          } else {
            pcrFormatType(
              rows = 16L,
              columns = 24L,
              rowLabel = labelFormatType("ABC"),
              columnLabel = labelFormatType("123")
            )
          }
        } else {
          rows <- .getIntegerValue(run, "rdml:pcrFormat/rdml:rows")
          cols <- .getIntegerValue(run, "rdml:pcrFormat/rdml:columns")
          if (!is.na(rows) && !is.na(cols)) {
            pcrFormatType(
              rows = rows,
              columns = cols,
              rowLabel = labelFormatType(.getTextValue(run, "rdml:pcrFormat/rdml:rowLabel")),
              columnLabel = labelFormatType(.getTextValue(run, "rdml:pcrFormat/rdml:columnLabel"))
            )
          } else {
            pcrFormatType(
              rows = 8L,
              columns = 12L,
              rowLabel = labelFormatType("ABC"),
              columnLabel = labelFormatType("123")
            )
          }
        }
      }
      
      if (showProgress) cat(sprintf("\n\trun: %s\n", runId))
      
      softwareNode <- xml2::xml_find_first(run, "rdml:dataCollectionSoftware", rdmlEnv$ns)
      software <- if (.isXmlMissing(softwareNode)) {
        NA
      } else {
        tryCatch(
          dataCollectionSoftwareType(
            name = .getTextValue(softwareNode, "rdml:name"),
            version = .getTextValue(softwareNode, "rdml:version")
          ),
          error = function(e) NA
        )
      }
      
      cqText <- .getTextValue(run, "rdml:cqDetectionMethod")
      cqMethod <- if (is.na(cqText)) {
        NA
      } else {
        tryCatch(cqDetectionMethodType(cqText), error = function(e) NA)
      }
      
      tccNode <- xml2::xml_find_first(run, "rdml:thermalCyclingConditions", rdmlEnv$ns)
      tccRef <- if (.isXmlMissing(tccNode)) NA else .genIdRef(tccNode)
      
      runType(
        id = idType(runId),
        description = .getTextValue(run, "rdml:description"),
        documentation = parseIdRefs(run, "rdml:documentation"),
        experimenter = parseIdRefs(run, "rdml:experimenter"),
        instrument = .getTextValue(run, "rdml:instrument"),
        dataCollectionSoftware = software,
        backgroundDeterminationMethod = .getTextValue(run, "rdml:backgroundDeterminationMethod"),
        cqDetectionMethod = cqMethod,
        thermalCyclingConditions = tccRef,
        pcrFormat = pcrFormat,
        runDate = .getTextValue(run, "rdml:runDate"),
        react = .compact(.xmlNodesApply(
          xml2::xml_find_all(run, "rdml:react", rdmlEnv$ns),
          function(node) GetReact(node, pcrFormat)
        ))
      )
    }
    
    # experiment -----------------------------------------------------------
    GetExperiment <- function(experiment) {
      experimentId <- xml2::xml_attr(experiment, "id")
      if (showProgress) cat(sprintf("\nLoading experiment: %s", experimentId))
      
      experimentType(
        id = idType(experimentId),
        description = .getTextValue(experiment, "rdml:description"),
        documentation = parseIdRefs(experiment, "rdml:documentation"),
        run = .xmlNodesApply(
          xml2::xml_find_all(experiment, "rdml:run", rdmlEnv$ns),
          GetRun
        )
      )
    }
    
    rdmlObj$experiment <- .xmlNodesApply(
      xml2::xml_find_all(rdmlDoc, "/rdml:rdml/rdml:experiment", rdmlEnv$ns),
      GetExperiment
    )
    
    # Combine CFX96 runs to one. Work on ordinary list properties so that
    # no physical list names are required at any stage.
    if (
      identical(publisher, "Bio-Rad Laboratories, Inc.") &&
      length(rdmlObj$experiment) >= 1L
    ) {
      exp1 <- rdmlObj$experiment[[1]]
      runs <- S7::prop(exp1, "run")
      
      if (is.list(runs) && length(runs) > 1L) {
        if (showProgress) cat("\nCombining Bio-Rad runs\n")
        firstRun <- runs[[1]]
        firstReacts <- S7::prop(firstRun, "react")
        
        for (runI in 2:length(runs)) {
          currentRun <- runs[[runI]]
          currentReacts <- S7::prop(currentRun, "react")
          
          for (react in currentReacts) {
            reactId <- .getId(react)
            existing <- .listGetByKey(firstReacts, reactId, "id")
            
            if (is.null(existing)) {
              firstReacts <- .listSetByKey(firstReacts, reactId, react, "id")
            } else {
              existingData <- S7::prop(existing, "data")
              newData <- S7::prop(react, "data")
              if (.isSingleNA(existingData)) existingData <- list()
              if (.isSingleNA(newData)) newData <- list()
              S7::prop(existing, "data") <- c(existingData, newData)
              firstReacts <- .listSetByKey(firstReacts, reactId, existing, "id")
            }
          }
        }
        
        S7::prop(firstRun, "react") <- firstReacts
        S7::prop(firstRun, "id") <- idType("Combined Run")
        S7::prop(exp1, "run") <- list(firstRun)
        rdmlObj$experiment[[1]] <- exp1
      }
    }
    
    # Roche LC96 post-processing ------------------------------------------
    if (isRoche) {
      # Rename sample ids to descriptions. Lists stay physically unnamed;
      # later rdml$sample exposes them through rdmlKeyedList.
      for (i in seq_along(rdmlObj$sample)) {
        sampleObj <- rdmlObj$sample[[i]]
        desc <- S7::prop(sampleObj, "description")
        
        if (!is.na(desc) && nzchar(desc)) {
          S7::prop(sampleObj, "id") <- idType(desc)
          rdmlObj$sample[[i]] <- sampleObj
        }
      }
      
      # Add Roche reference-gene flags.
      if (!is.null(refGenesR) && length(refGenesR) != 0L && !.isSingleNA(refGenesR)) {
        ns <- xml2::xml_ns_rename(xml2::xml_ns(refGenesR), d3 = "rel")
        for (i in seq_along(refGenesR)) {
          refGene <- refGenesR[[i]]
          geneName <- .getTextValue(refGene, "rel:geneName", ns = ns)
          targetObj <- .listGetByKey(rdmlObj$target, geneName, "id")
          if (!is.null(targetObj)) {
            isRef <- .getLogicalValue(refGene, "rel:isReference", ns = ns)
            S7::prop(targetObj, "type") <-
              targetTypeType(if (isTRUE(isRef)) "ref" else "toi")
            rdmlObj$target <- .listSetByKey(rdmlObj$target, geneName, targetObj, "id")
          }
        }
      }
      
      # Add Roche quantities using the target-aware quantityType schema.
      #
      # Roche calculated_data.xml groups dilution-series information by dye
      # (FAM, Hex, Texas Red, Cy5), while quantityType requires targetId.
      # Resolve the actual target for each reaction through:
      #
      #   react -> data -> target -> dye
      #
      # The same sample can occur in several technical replicate wells, so
      # quantities must be upserted by targetId rather than appended.
      
      if (is.list(dilutionsR) && length(dilutionsR)) {
        
        findRocheSampleTarget <- function(
    reactId,
    dyeId) {
          
          reactId <- as.character(reactId)
          
          for (experimentObj in rdmlObj$experiment) {
            runs <- S7::prop(experimentObj, "run")
            
            if (.isSingleNA(runs) || !length(runs)) {
              next
            }
            
            for (runObj in runs) {
              reacts <- S7::prop(runObj, "react")
              
              if (.isSingleNA(reacts) || !length(reacts)) {
                next
              }
              
              reactObj <- .listGetByKey(
                reacts,
                reactId,
                "id"
              )
              
              if (is.null(reactObj)) {
                next
              }
              
              sampleName <- .rdmlIdChr(
                S7::prop(reactObj, "sample")
              )
              
              dataList <- S7::prop(
                reactObj,
                "data"
              )
              
              if (.isSingleNA(dataList) || !length(dataList)) {
                next
              }
              
              for (dataObj in dataList) {
                targetId <- .rdmlIdChr(
                  S7::prop(dataObj, "targetId")
                )
                
                if (is.na(targetId)) {
                  next
                }
                
                targetObj <- .listGetByKey(
                  rdmlObj$target,
                  targetId,
                  "id"
                )
                
                if (is.null(targetObj)) {
                  next
                }
                
                targetDyeId <- .rdmlIdChr(
                  S7::prop(targetObj, "dyeId")
                )
                
                if (
                  !is.na(targetDyeId) &&
                  identical(targetDyeId, dyeId)
                ) {
                  return(
                    list(
                      sample = sampleName,
                      targetId = targetId
                    )
                  )
                }
              }
            }
          }
          
          NULL
        }
        
        for (dyeId in names(dilutionsR)) {
          dyeDilutions <- dilutionsR[[dyeId]]
          
          for (rId in names(dyeDilutions)) {
            mapping <- findRocheSampleTarget(
              reactId = rId,
              dyeId = dyeId
            )
            
            if (is.null(mapping)) {
              next
            }
            
            sampleName <- mapping$sample
            targetId <- mapping$targetId
            
            if (is.na(sampleName) || is.na(targetId)) {
              next
            }
            
            sampleObj <- .listGetByKey(
              rdmlObj$sample,
              sampleName,
              "id"
            )
            
            if (is.null(sampleObj)) {
              next
            }
            
            quantities <- S7::prop(
              sampleObj,
              "quantity"
            )
            
            if (.isSingleNA(quantities) || !length(quantities)) {
              quantities <- list()
            }
            
            quantityObj <- quantityType(
              targetId = idReferenceType(targetId),
              value = unname(dyeDilutions[rId]),
              unit = quantityUnitType("other")
            )
            
            quantities <- .rdmlUpsertListByKey(
              quantities,
              quantityObj,
              key = "targetId"
            )
            
            S7::prop(
              sampleObj,
              "quantity"
            ) <- quantities
            
            rdmlObj$sample <- .listSetByKey(
              rdmlObj$sample,
              sampleName,
              sampleObj,
              "id"
            )
          }
        }
      }
      
      # Roche-derived conditions are kept separate for now. Native RDML
      # <annotation> elements are imported above; mapping Roche condition
      # metadata into annotations is intentionally deferred to a vendor-specific
      # cleanup pass so this refactor does not change import semantics.
      invisible(conditionsR)
    }
    
    rdmlObj
  }
  
  rdmlObj <- fromRDML()
  do.call(rdmlType, rdmlObj)
}
